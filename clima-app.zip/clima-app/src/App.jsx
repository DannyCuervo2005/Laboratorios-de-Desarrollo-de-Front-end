import { useState, useEffect } from 'react';
import Formulario from './components/Formulario';
import TarjetaClima from './components/TarjetaClima';
import './App.css';

function App() {
  const [clima, setClima] = useState(null);
  const [cargando, setCargando] = useState(false);
  const [error, setError] = useState(null);
  const [claseFondo, setClaseFondo] = useState('bg-despejado');

  // Función para determinar el estilo de fondo y los datos descriptivos
  const evaluarEstadoClima = (code, esDia) => {
    if (!esDia) return { texto: 'Noche despejada', icono: '🌙', bg: 'bg-noche' };
    if (code === 0) return { texto: 'Cielo despejado', icono: '☀️', bg: 'bg-despejado' };
    if (code >= 1 && code <= 3) return { texto: 'Parcialmente nublado', icono: '⛅', bg: 'bg-nublado' };
    if (code >= 45 && code <= 48) return { texto: 'Niebla / Neblina', icono: '🌫️', bg: 'bg-niebla' };
    if (code >= 51 && code <= 67) return { texto: 'Lluvia ligera / moderada', icono: '🌧️', bg: 'bg-lluvia' };
    if (code >= 80 && code <= 82) return { texto: 'Chubascos', icono: '🌦️', bg: 'bg-lluvia' };
    if (code >= 95) return { texto: 'Tormenta eléctrica', icono: '🌩️', bg: 'bg-tormenta' };
    return { texto: 'Clima variable', icono: '🌡️', bg: 'bg-despejado' };
  };

  const obtenerClima = async (nombreCiudad) => {
    setCargando(true);
    setError(null);

    try {
      // 1. Geocodificación
      const geoUrl = `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(nombreCiudad)}&count=1&language=es&format=json`;
      const resGeo = await fetch(geoUrl);
      const dataGeo = await resGeo.json();

      if (!dataGeo.results || dataGeo.results.length === 0) {
        setError(`No se encontraron resultados para "${nombreCiudad}".`);
        setClima(null);
        setCargando(false);
        return;
      }

      const { latitude, longitude, name, admin1, country_code } = dataGeo.results[0];
      const nombreCompleto = `${name}${admin1 ? `, ${admin1}` : ''} (${country_code})`;

      // 2. Consulta de API extendida (pedimos UV, presión, prob. lluvia y es_dia)
      const climaUrl = `https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,weather_code,surface_pressure,wind_speed_10m&hourly=precipitation_probability,uv_index&timezone=auto`;
      const resClima = await fetch(climaUrl);
      const dataClima = await resClima.json();

      const current = dataClima.current;
      // Tomamos el UV y probabilidad de lluvia del arreglo horario actual
      const probLluviaActual = dataClima.hourly?.precipitation_probability?.[0] ?? 0;
      const uvActual = dataClima.hourly?.uv_index?.[0] ?? 0;

      const estado = evaluarEstadoClima(current.weather_code, current.is_day);
      setClaseFondo(estado.bg); // Actualizamos la clase del fondo del body/app

      setClima({
        nombre: nombreCompleto,
        temp: Math.round(current.temperature_2m),
        sensacion: Math.round(current.apparent_temperature),
        humedad: current.relative_humidity_2m,
        viento: current.wind_speed_10m,
        probLluvia: probLluviaActual,
        indiceUV: uvActual,
        presion: Math.round(current.surface_pressure),
        estadoTexto: estado.texto,
        icono: estado.icono
      });

    } catch (err) {
      console.error('Error durante la consulta:', err);
      setError('Ocurrió un error al consultar el servicio.');
    } finally {
      setCargando(false);
    }
  };

  useEffect(() => {
    obtenerClima('Montemorelos');
  }, []);

  return (
    <div className={`app-wrapper ${claseFondo}`}>
      <div className="container">
        <header>
          <h1>🌤️ Monitor Meteorológico</h1>
          <p className="subtitulo">Consumo API REST - Open-Meteo</p>
        </header>

        <Formulario alBuscar={obtenerClima} />

        {cargando && <p className="mensaje-info">Obteniendo datos del clima...</p>}
        {error && <p className="mensaje-error">{error}</p>}
        {clima && !cargando && <TarjetaClima clima={clima} />}
      </div>
    </div>
  );
}

export default App;