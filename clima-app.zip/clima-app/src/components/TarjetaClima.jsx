function TarjetaClima({ clima }) {
  const { 
    nombre, 
    temp, 
    sensacion, 
    humedad, 
    viento, 
    probLluvia, 
    indiceUV, 
    presion, 
    estadoTexto, 
    icono 
  } = clima;

  // Helper para calificar el índice UV
  const nivelUV = (uv) => {
    if (uv <= 2) return 'Bajo 🟢';
    if (uv <= 5) return 'Moderado 🟡';
    if (uv <= 7) return 'Alto 🟠';
    return 'Muy Alto 🔴';
  };

  return (
    <div className="clima-card">
      <h2>{nombre}</h2>
      
      <div className="temp-box">
        <span className="icono">{icono}</span>
        <span className="temperatura">{temp}°C</span>
      </div>

      <p className="descripcion">{estadoTexto}</p>

      {/* Grid ampliada con 6 métricas clave */}
      <div className="detalles-grid">
        <div className="detalle-item">
          <span>Sensación</span>
          <strong>{sensacion}°C</strong>
        </div>
        <div className="detalle-item">
          <span>Humedad</span>
          <strong>{humedad}%</strong>
        </div>
        <div className="detalle-item">
          <span>Viento</span>
          <strong>{viento} km/h</strong>
        </div>
        <div className="detalle-item">
          <span>Prob. Lluvia</span>
          <strong>{probLluvia}%</strong>
        </div>
        <div className="detalle-item">
          <span>Índice UV</span>
          <strong>{indiceUV} ({nivelUV(indiceUV)})</strong>
        </div>
        <div className="detalle-item">
          <span>Presión</span>
          <strong>{presion} hPa</strong>
        </div>
      </div>
    </div>
  );
}

export default TarjetaClima;