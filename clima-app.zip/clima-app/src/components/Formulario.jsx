import { useState } from 'react';

function Formulario({ alBuscar }) {
  // Estado local para capturar el texto que escribe el usuario
  const [ciudadInput, setCiudadInput] = useState('');

  // Manejador del submit del formulario
  const handleSubmit = (e) => {
    e.preventDefault(); // Prevenimos el recargo de la página
    
    // Validacion sencilla para evitar enviar campos vacíos
    if (ciudadInput.trim() === '') {
      alert('Por favor escribe el nombre de una ciudad.');
      return;
    }

    // Enviamos el valor al componente padre (App.jsx)
    alBuscar(ciudadInput);
  };

  return (
    <form onSubmit={handleSubmit} className="busqueda-form">
      <input
        type="text"
        placeholder="Ej. Montemorelos, Monterrey, Madrid..."
        value={ciudadInput}
        onChange={(e) => setCiudadInput(e.target.value)}
      />
      <button type="submit">Buscar Clima</button>
    </form>
  );
}

export default Formulario;